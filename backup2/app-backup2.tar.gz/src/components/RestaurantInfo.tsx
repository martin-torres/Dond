import { useState } from 'react';
import { MapPin, Clock, Users, Tag, CheckCircle2 } from 'lucide-react';
import { Restaurant, Language, Promo } from '../types';
import { t } from '../utils/translations';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Input } from './ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';

interface RestaurantInfoProps {
  restaurant: Restaurant;
  language: Language;
  onContinue: () => void;
  // Optional: parent can handle ordering directly from a promo
  onOrderFromPromo?: (promoId: string) => void;
}

const HOLD_PAYMENT_OPTIONS = [
  { value: 'apple-pay', label: 'Apple Pay' },
  { value: 'visa', label: 'Visa' },
  { value: 'mastercard', label: 'Mastercard' },
  { value: 'amex', label: 'American Express' },
  { value: 'credit-card', label: 'Credit / Debit Card' },
];

export function RestaurantInfo({
  restaurant,
  language,
  onContinue,
  onOrderFromPromo,
}: RestaurantInfoProps) {
  const [isPromoDialogOpen, setPromoDialogOpen] = useState(false);
  const [activePromo, setActivePromo] = useState<Promo | null>(null);
  const [guestName, setGuestName] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [promoReservations, setPromoReservations] = useState<
    Record<string, { name: string; paymentMethod: string }>
  >({});

  const handlePromoDialogChange = (open: boolean) => {
    setPromoDialogOpen(open);
    if (!open) {
      setShowConfirmation(false);
      setActivePromo(null);
      setGuestName('');
      setPaymentMethod('');
    }
  };

  const handlePromoButtonClick = (promo: Promo) => {
    setActivePromo(promo);
    const existing = promoReservations[promo.id];
    setGuestName(existing?.name ?? '');
    setPaymentMethod(existing?.paymentMethod ?? '');
    setShowConfirmation(Boolean(existing));
    setPromoDialogOpen(true);
  };

  const getPaymentLabel = (value: string) =>
    HOLD_PAYMENT_OPTIONS.find((option) => option.value === value)?.label ??
    value;

  const handleConfirmPromo = () => {
    if (!activePromo) return;
    const trimmedName = guestName.trim();
    if (!trimmedName || !paymentMethod) return;

    setPromoReservations((prev) => ({
      ...prev,
      [activePromo.id]: {
        name: trimmedName,
        paymentMethod,
      },
    }));

    if (onOrderFromPromo) {
      onOrderFromPromo(activePromo.id);
    }

    setGuestName(trimmedName);
    setShowConfirmation(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4 pb-24">
      <div className="max-w-2xl mx-auto space-y-4">
        {/* Restaurant Header */}
        <Card className="p-6">
          <div className="space-y-4">
            <div>
              <h1 className="text-gray-900 mb-2">{restaurant.name}</h1>
              <div className="flex items-start gap-2 text-gray-600">
                <MapPin className="w-5 h-5 mt-0.5 flex-shrink-0" />
                <span>{restaurant.address}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="text-gray-900">{t('hours', language)}</p>
                  <p className="text-gray-600">
                    {restaurant.hours.open} - {restaurant.hours.close}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-600" />
                <div>
                  <p className="text-gray-900">{t('waitTime', language)}</p>
                  <p className="text-gray-600">
                    {restaurant.waitTime} {t('minutes', language)}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2 border-t">
              <MapPin className="w-5 h-5 text-green-600" />
              <p className="text-gray-600">
                {t('distance', language)}: {restaurant.distance} {t('meters', language)}
              </p>
            </div>
          </div>
        </Card>

        {/* Promotions */}
        {restaurant.promos.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Tag className="w-5 h-5 text-orange-600" />
              <h2 className="text-gray-900">{t('todaysPromos', language)}</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {restaurant.promos.map((promo) => (
                <Card
                  key={promo.id}
                  className="overflow-hidden border-2 border-orange-200 hover:border-orange-400 transition-all hover:shadow-lg"
                >
                  {promo.imageUrl && (
                    <div className="relative h-48 w-full overflow-hidden">
                      <ImageWithFallback
                        src={promo.imageUrl}
                        alt={promo.title[language]}
                        className="w-full h-full object-cover"
                      />
                      {promo.discount > 0 && (
                        <div className="absolute top-3 right-3">
                          <Badge className="bg-orange-600 text-white text-lg px-4 py-2 shadow-lg">
                            {promo.discount}% {t('off', language)}
                          </Badge>
                        </div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                      <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                        <h3 className="mb-1">{promo.title[language]}</h3>
                      </div>
                    </div>
                  )}
                  <div className="p-4">
                    {!promo.imageUrl && (
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <h3 className="text-gray-900">{promo.title[language]}</h3>
                        {promo.discount > 0 && (
                          <Badge className="bg-orange-600 text-white flex-shrink-0">
                            {promo.discount}% {t('off', language)}
                          </Badge>
                        )}
                      </div>
                    )}

                    {/* Description: what the promo includes */}
                    <p className="text-gray-600">{promo.description[language]}</p>

                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Fixed bottom button */}
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t shadow-lg">
          <div className="max-w-2xl mx-auto">
            <Button onClick={onContinue} className="w-full" size="lg">
              {t('viewMenu', language)}
            </Button>
          </div>
        </div>
      </div>

      <Dialog open={isPromoDialogOpen} onOpenChange={handlePromoDialogChange}>
        <DialogContent className="sm:max-w-md">
          {activePromo && !showConfirmation && (
            <>
              <DialogHeader>
                <DialogTitle>
                  {language === 'es'
                    ? `Separar promo • ${activePromo.title[language]}`
                    : `Hold promo • ${activePromo.title[language]}`}
                </DialogTitle>
                <DialogDescription>
                  {language === 'es'
                    ? 'Guardaremos tu método de pago (sin cobrar aún) y asignaremos la orden a tu nombre o a una mesa provisional para que la recibas apenas llegues.'
                    : 'We’ll keep a payment method on file (no charge yet) and tag the order with your name or a provisional waitlist table so it’s ready the moment you arrive.'}
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-gray-700">
                    {language === 'es' ? '¿A nombre de quién?' : 'Name for the order'}
                  </label>
                  <Input
                    value={guestName}
                    onChange={(event) => setGuestName(event.target.value)}
                    placeholder={
                      language === 'es'
                        ? 'Ej. Mariana / Grupo López'
                        : 'Ex. Alex / Lopez party'
                    }
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-gray-700">
                    {language === 'es'
                      ? 'Método de pago preferido'
                      : 'Preferred payment method'}
                  </label>
                  <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                    <SelectTrigger className="w-full">
                      <SelectValue
                        placeholder={
                          language === 'es'
                            ? 'Selecciona un método'
                            : 'Choose a method'
                        }
                      />
                    </SelectTrigger>
                    <SelectContent>
                      {HOLD_PAYMENT_OPTIONS.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-[11px] text-gray-500">
                    {language === 'es'
                      ? 'Solo validamos el método; no se hace ningún cargo hasta que recibas tus bebidas.'
                      : 'We simply verify the method; no charges happen until the drinks are delivered.'}
                  </p>
                </div>
              </div>

              <DialogFooter className="pt-4">
                <Button
                  variant="ghost"
                  onClick={() => handlePromoDialogChange(false)}
                >
                  {language === 'es' ? 'Cancelar' : 'Cancel'}
                </Button>
                <Button
                  onClick={handleConfirmPromo}
                  disabled={!guestName.trim() || !paymentMethod}
                >
                  {language === 'es' ? 'Confirmar y separar' : 'Confirm & hold'}
                </Button>
              </DialogFooter>
            </>
          )}

          {activePromo && showConfirmation && (
            <>
              <DialogHeader>
                <DialogTitle>
                  {language === 'es' ? '¡Listo!' : 'You’re all set'}
                </DialogTitle>
                <DialogDescription>
                  {language === 'es'
                    ? 'Tus bebidas están en camino con prioridad de barra.'
                    : 'Your drinks are queued up with bar priority.'}
                </DialogDescription>
              </DialogHeader>

              <div className="rounded-2xl border border-green-100 bg-green-50 p-4 flex gap-3">
                <CheckCircle2 className="h-10 w-10 text-green-600 flex-shrink-0" />
                <div className="space-y-1 text-sm text-green-900">
                  <p className="font-semibold">
                    {language === 'es'
                      ? `Gracias, ${guestName}!`
                      : `Thanks, ${guestName}!`}
                  </p>
                  <p>
                    {language === 'es'
                    ? `Agregamos la promo "${activePromo.title[language]}" a tu mesa provisional bajo tu nombre.`
                    : `We added the "${activePromo.title[language]}" promo to your provisional waitlist table under your name.`}
                  </p>
                  <p>
                    {language === 'es'
                      ? `Guardamos ${getPaymentLabel(paymentMethod)} sin cargos; pagas hasta que recibas tus bebidas.`
                      : `We saved ${getPaymentLabel(paymentMethod)} with zero charges—nothing runs until the tray hits your table.`}
                  </p>
                </div>
              </div>

              <p className="text-sm text-gray-600">
                {language === 'es'
                  ? 'Cuando escuchemos tu nombre, te entregaremos las bebidas incluso si sigues en la lista de espera.'
                  : 'We’ll call out your name when the drinks leave the bar, even if you’re still on a provisional waitlist table.'}
              </p>

              <DialogFooter className="pt-2">
                <Button
                  className="w-full"
                  onClick={() => handlePromoDialogChange(false)}
                >
                  {language === 'es' ? 'Perfecto, gracias' : 'Great, thanks'}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
