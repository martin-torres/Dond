import { useMemo, useState } from 'react';
import { Bill, Language } from '../types';
import { Button } from './ui/button';

type BillPaymentProps = {
  bill: Bill;
  language: Language;
  onPaymentComplete: (paidAmount?: number, paidItems?: string[]) => void;
};

export function BillPayment({
  bill,
  language,
  onPaymentComplete,
}: BillPaymentProps) {
  type SplitMethod = 'full' | 'even' | 'items';
  const [splitMethod, setSplitMethod] = useState<SplitMethod>('full');
  const [partySize, setPartySize] = useState(2);
  const [itemSelections, setItemSelections] = useState<Record<string, number>>(
    {}
  );

  const taxRate = bill.subtotal > 0 ? bill.tax / bill.subtotal : 0;
  const tipRate = bill.subtotal > 0 ? bill.tip / bill.subtotal : 0;

  const getItemKey = (itemId: string, idx: number) => `${itemId}-${idx}`;

  const selectedItemsSubtotal = useMemo(() => {
    return bill.items.reduce((sum, item, idx) => {
      const key = getItemKey(item.menuItem.id, idx);
      const qty = itemSelections[key] ?? 0;
      return sum + qty * item.menuItem.price;
    }, 0);
  }, [bill.items, itemSelections]);

  const selectedItemsTotal = useMemo(() => {
    if (splitMethod !== 'items') return 0;
    const multiplier = 1 + taxRate + tipRate;
    return selectedItemsSubtotal * (multiplier || 1);
  }, [splitMethod, selectedItemsSubtotal, taxRate, tipRate]);

  const amountToPay = useMemo(() => {
    if (splitMethod === 'even') {
      const safePartySize = Math.max(1, partySize);
      return bill.total / safePartySize;
    }

    if (splitMethod === 'items') {
      return selectedItemsTotal;
    }

    return bill.total;
  }, [bill.total, partySize, selectedItemsTotal, splitMethod]);

  const handleItemSelection = (key: string, nextQuantity: number) => {
    setItemSelections((prev) => {
      if (nextQuantity <= 0) {
        const { [key]: _removed, ...rest } = prev;
        return rest;
      }
      return {
        ...prev,
        [key]: nextQuantity,
      };
    });
  };

  const selectedItemsIds = () => {
    const ids: string[] = [];
    bill.items.forEach((item, idx) => {
      const key = getItemKey(item.menuItem.id, idx);
      const qty = itemSelections[key] ?? 0;
      for (let i = 0; i < qty; i++) {
        ids.push(item.menuItem.id);
      }
    });
    return ids;
  };

  const getMethodLabel = () => {
    if (splitMethod === 'even') {
      return language === 'es' ? 'un pago dividido' : 'a split payment';
    }
    if (splitMethod === 'items') {
      return language === 'es' ? 'un pago por artículo' : 'an itemized payment';
    }
    return language === 'es' ? 'un pago completo' : 'a full payment';
  };

  const handlePayment = () => {
    if (splitMethod === 'items' && selectedItemsTotal <= 0) {
      alert(
        language === 'es'
          ? 'Selecciona al menos un artículo para pagar.'
          : 'Select at least one item to pay for.'
      );
      return;
    }

    const amount = Number(amountToPay.toFixed(2));
    const methodLabel = getMethodLabel();

    alert(
      language === 'es'
        ? `Procesando ${methodLabel} por $${amount.toFixed(2)}`
        : `Processing ${methodLabel} for $${amount.toFixed(2)}`
    );

    const paidItems =
      splitMethod === 'items'
        ? selectedItemsIds()
        : bill.items.map((item) => item.menuItem.id);
    onPaymentComplete(amount, paidItems);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="bg-white shadow-sm px-4 py-3">
        <h1 className="text-xl font-semibold">
          {language === 'es' ? 'Pago de cuenta' : 'Bill Payment'}
        </h1>
        <p className="text-xs text-gray-500">
          {language === 'es'
            ? 'Selecciona tu método de pago preferido.'
            : 'Select your preferred payment method.'}
        </p>
      </header>

      <main className="flex-1 px-4 py-4 space-y-4">
        {/* Bill summary */}
        <section className="bg-white rounded-xl shadow-sm p-4 border">
          <h2 className="text-sm font-semibold mb-2">
            {language === 'es' ? 'Resumen' : 'Summary'}
          </h2>
          <ul className="space-y-1 text-sm text-gray-700 max-h-40 overflow-y-auto">
            {bill.items.map((item, idx) => (
              <li key={idx} className="flex justify-between">
                <span>
                  {item.quantity}× {item.menuItem.name.en}
                </span>
                <span>
                  ${(item.menuItem.price * item.quantity).toFixed(2)}
                </span>
              </li>
            ))}
          </ul>
          <div className="border-t mt-2 pt-2 text-sm">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span>${bill.subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>{language === 'es' ? 'Impuestos' : 'Tax'}</span>
              <span>${bill.tax.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>{language === 'es' ? 'Propina' : 'Tip'}</span>
              <span>${bill.tip.toFixed(2)}</span>
            </div>
            <div className="flex justify-between font-semibold mt-1">
              <span>{language === 'es' ? 'Total' : 'Total'}</span>
              <span>${bill.total.toFixed(2)}</span>
            </div>
          </div>
        </section>

        {/* Payment split options */}
        <section className="bg-white rounded-xl shadow-sm p-4 border space-y-4">
          <h2 className="text-sm font-semibold">
            {language === 'es'
              ? '¿Cómo quieres pagar?'
              : 'How would you like to pay?'}
          </h2>

          <div className="grid grid-cols-1 gap-2 md:grid-cols-3">
            <Button
              variant={splitMethod === 'full' ? 'default' : 'outline'}
              onClick={() => setSplitMethod('full')}
            >
              {language === 'es' ? 'Pagar todo' : 'Pay in full'}
            </Button>
            <Button
              variant={splitMethod === 'even' ? 'default' : 'outline'}
              onClick={() => setSplitMethod('even')}
            >
              {language === 'es' ? 'Dividir equitativo' : 'Split evenly'}
            </Button>
            <Button
              variant={splitMethod === 'items' ? 'default' : 'outline'}
              onClick={() => setSplitMethod('items')}
            >
              {language === 'es' ? 'Por artículo' : 'Split by item'}
            </Button>
          </div>

          {splitMethod === 'even' && (
            <div className="space-y-2">
              <label className="text-xs text-gray-600">
                {language === 'es'
                  ? '¿Entre cuántas personas se divide la cuenta?'
                  : 'How many people are splitting the bill?'}
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  min={1}
                  value={partySize}
                  onChange={(e) => setPartySize(Math.max(1, Number(e.target.value) || 1))}
                  className="w-20 rounded-md border border-gray-300 px-2 py-1 text-sm"
                />
                <p className="text-sm text-gray-600">
                  {language === 'es' ? 'Cada persona paga' : 'Each person pays'}{' '}
                  <span className="font-semibold">
                    ${amountToPay.toFixed(2)}
                  </span>
                </p>
              </div>
            </div>
          )}

          {splitMethod === 'items' && (
            <div className="space-y-3">
              <p className="text-xs text-gray-600">
                {language === 'es'
                  ? 'Selecciona artículos para cubrir en este pago'
                  : 'Select the items you want to cover with this payment'}
              </p>
              <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
                {bill.items.map((item, idx) => {
                  const key = getItemKey(item.menuItem.id, idx);
                  const selectedQty = itemSelections[key] ?? 0;
                  return (
                    <div
                      key={key}
                      className="flex items-center justify-between rounded-lg border px-3 py-2 text-sm"
                    >
                      <div>
                        <p className="font-medium">{item.menuItem.name.en}</p>
                        <p className="text-xs text-gray-500">
                          ${item.menuItem.price.toFixed(2)} •{' '}
                          {language === 'es' ? 'Disponibles' : 'Available'}:{' '}
                          {item.quantity}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() =>
                            handleItemSelection(key, Math.max(0, selectedQty - 1))
                          }
                        >
                          −
                        </Button>
                        <span className="w-6 text-center">{selectedQty}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() =>
                            handleItemSelection(
                              key,
                              Math.min(item.quantity, selectedQty + 1)
                            )
                          }
                        >
                          +
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="text-sm text-gray-700">
                <p>
                  {language === 'es' ? 'Total seleccionado' : 'Selected total'}:{' '}
                  <span className="font-semibold">
                    ${selectedItemsSubtotal.toFixed(2)}{' '}
                    {language === 'es' ? '(antes de impuestos y propina)' : '(before tax & tip)'}
                  </span>
                </p>
                <p>
                  {language === 'es'
                    ? 'Pago estimado con impuestos y propina'
                    : 'Estimated payment with tax & tip'}:{' '}
                  <span className="font-semibold">
                    ${selectedItemsTotal.toFixed(2)}
                  </span>
                </p>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between border-t pt-3 text-sm">
            <span className="text-gray-600">
              {language === 'es' ? 'Monto a pagar ahora' : 'Amount to pay now'}
            </span>
            <span className="text-lg font-semibold">
              ${amountToPay.toFixed(2)}
            </span>
          </div>

          <Button
            className="w-full"
            onClick={handlePayment}
            disabled={splitMethod === 'items' && selectedItemsTotal <= 0}
          >
            {language === 'es' ? 'Confirmar y pagar' : 'Confirm & Pay'}
          </Button>
        </section>
      </main>
    </div>
  );
}
