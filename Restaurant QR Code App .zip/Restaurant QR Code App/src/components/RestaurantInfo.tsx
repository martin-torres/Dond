import { MapPin, Clock, Users, Tag } from 'lucide-react';
import { Restaurant, Language } from '../types';
import { t } from '../utils/translations';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface RestaurantInfoProps {
  restaurant: Restaurant;
  language: Language;
  onContinue: () => void;
}

export function RestaurantInfo({ restaurant, language, onContinue }: RestaurantInfoProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-3 pb-24">
      <div className="max-w-2xl mx-auto space-y-4">
        {/* Compact Restaurant Header – very small vertical footprint */}
        <div className="space-y-1 pt-1">
          {/* Line 1: Name + distance + wait time */}
          <div className="flex items-baseline justify-between gap-2">
            <<h1 className="text-lg font-semibold text-red-600">
             DEBUG RESTAURANT HEADER — {restaurant.name}
            </h1>

            <div className="flex items-center gap-3 text-xs text-gray-600 flex-shrink-0">
              <div className="flex items-center gap-1">
                <MapPin className="w-3 h-3" />
                <span>
                  {restaurant.distance} {t('meters', language)}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <Users className="w-3 h-3" />
                <span>
                  {t('waitTime', language)}: {restaurant.waitTime}{' '}
                  {t('minutes', language)}
                </span>
              </div>
            </div>
          </div>

          {/* Line 2: Address */}
          <div className="flex items-start gap-1 text-xs text-gray-600">
            <MapPin className="w-3 h-3 mt-0.5 flex-shrink-0" />
            <span className="leading-snug">{restaurant.address}</span>
          </div>

          {/* Line 3: Hours */}
          <div className="flex items-center gap-2 text-xs text-gray-600">
            <Clock className="w-3 h-3" />
            <span>
              {t('hours', language)}: {restaurant.hours.open} –{' '}
              {restaurant.hours.close}
            </span>
          </div>
        </div>

        {/* (Optional) Main Event space – the first promo will visually feel like the hero */}
        {restaurant.promos.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Tag className="w-5 h-5 text-orange-600" />
              <h2 className="text-sm font-semibold text-red-600">
                DEBUG PROMOS – {t('todaysPromos', language)}
              </h2>
            </div>

            {/* Promos grid: ALWAYS 2 columns on phone so 2 cards side by side */}
            <div className="grid grid-cols-2 gap-3">
              {restaurant.promos.map((promo) => (
                <Card
                  key={promo.id}
                  className="overflow-hidden border border-orange-200 hover:border-orange-400 transition-all hover:shadow-md"
                >
                  {promo.imageUrl && (
                    <div className="relative h-28 sm:h-32 w-full overflow-hidden">
                      <ImageWithFallback
                        src={promo.imageUrl}
                        alt={promo.title[language]}
                        className="w-full h-full object-cover"
                      />
                      {promo.discount > 0 && (
                        <div className="absolute top-2 right-2">
                          <Badge className="bg-orange-600 text-white text-xs px-2 py-1 shadow">
                            {promo.discount}% {t('off', language)}
                          </Badge>
                        </div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                      <div className="absolute bottom-0 left-0 right-0 px-2 pb-2 pt-4 text-xs text-white">
                        <h3 className="font-semibold leading-tight line-clamp-2">
                          {promo.title[language]}
                        </h3>
                      </div>
                    </div>
                  )}
                  <div className="p-2">
                    {!promo.imageUrl && (
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <h3 className="text-xs font-semibold text-gray-900 line-clamp-2">
                          {promo.title[language]}
                        </h3>
                        {promo.discount > 0 && (
                          <Badge className="bg-orange-600 text-white flex-shrink-0 text-[10px] px-2">
                            {promo.discount}% {t('off', language)}
                          </Badge>
                        )}
                      </div>
                    )}
                    <p className="text-[11px] leading-snug text-gray-600 line-clamp-3">
                      {promo.description[language]}
                    </p>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Fixed bottom button */}
        <div className="fixed bottom-0 left-0 right-0 p-3 bg-white border-t shadow-lg">
          <div className="max-w-2xl mx-auto">
            <Button onClick={onContinue} className="w-full" size="lg">
              {t('viewMenu', language)}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
